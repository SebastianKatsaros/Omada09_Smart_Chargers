'use strict';
import { Database } from 'sqlite-async';
import bcrypt from 'bcrypt';

let sql;
try {
    sql = await Database.open('model/db/smart-charging.sqlite');
} catch (error) {
    throw Error('Δεν ήταν δυνατό να ανοίξει η βάση δεδομένων.' + error);
}

export let getAllChargingPoints = async () => {
    const stmt = await sql.prepare("SELECT * FROM Charging_Point");
    try {
        const chargePoints = await stmt.all();
        return chargePoints;
    } catch (err) {
        throw err;
    }
}

export let getUserByUsername = async (username) => {
    const stmt = await sql.prepare("SELECT Username, Password FROM User WHERE Username = ? LIMIT 1");
    try {
        const user = await stmt.get(username);
        return user;
    } catch (err) {
        throw err;
    }
}

export let getAllMembers = async () => {
    const stmt = await sql.prepare("SELECT Username, FirstName, LastName FROM User ORDER BY LastName");
    try {
        const members = await stmt.all();
        return members;
    } catch (err) {
        throw err;
    }
}

export let registerUser = async function (username, password, first_name, last_name, phone, vehicle) {
    const user = await getUserByUsername(username);
    if (user != undefined) {
        return { message: "A user with this name already exists" };
    } else {
        try {
            const hashedPassword = await bcrypt.hash(password, 10);
            const stmt = await sql.prepare('INSERT INTO User (Username, Password, FirstName, LastName, Phone, Vehicle) VALUES (?, ?, ?, ?, ?, ?)');
            const info = await stmt.run(username, hashedPassword, first_name, last_name, phone, vehicle);
            return info.lastID;
        } catch (error) {
            throw error;
        }
    }
}

export let getChargingSpotAvailability = async (date, stationID) => {
    const stmt = await sql.prepare('SELECT Hour FROM Booking WHERE Date = ? AND ChargingSpotID = ?');
    try {
        const bookings = await stmt.all(date, stationID);
        return bookings;
    } catch (error) {
        throw error;
    }
};

export let saveChargingSpotBooking = async (date, memberUsername, stationID, hour) => {
    const stmt = await sql.prepare('INSERT INTO Booking (BookingID, ChargingSpotID, User, Date, Hour) VALUES (NULL,?, ?, ?, ?)');
    try {
        await stmt.run(stationID, memberUsername, date, hour);
    } catch (error) {
        throw error;
    }
};

export let getAllBookings = async () => {
    const stmt = await sql.prepare('SELECT * FROM Booking');
    try {
        const bookings = await stmt.all();
        return bookings;
    } catch (error) {
        console.error('Error retrieving all bookings:', error);  // Log errors for debugging
        throw error;
    }
};

export let getBookingsForMember = async (memberUsername) => {
    const stmt = await sql.prepare('SELECT * FROM Booking WHERE User = ? ORDER BY Date, Hour');
    try {
        const bookings = await stmt.all(memberUsername);
        return bookings;
    } catch (error) {
        console.error('Error retrieving bookings:', error);  // Log errors for debugging
        throw error;
    }
};

export let getMemberVehicle = async (memberUsername) => {
    const stmt = await sql.prepare('SELECT Vehicle FROM User WHERE Username = ?');
    try {
        const vehicle = await stmt.all(memberUsername);
        return vehicle;
    } catch (error) {
        console.error('Error retrieving bookings:', error);  // Log errors for debugging
        throw error;
    }
};

export let getUserBookingHours = async (username, date) => {
    const stmt = await sql.prepare("SELECT ChargingSpotID, Hour FROM Booking WHERE User = ? AND Date = ?");
    try {
        const bookings = await stmt.all(username, date);
        return bookings;
    } catch (err) {
        throw err;
    }
}

export let getChargingSpotInformation = async (chargingSpotID) => {
    const stmt = await sql.prepare("SELECT PlugType, PricePerkWh, Power, ACorDC FROM Charging_Point WHERE StationID = ?");
    try {
        const info = await stmt.all(chargingSpotID);
        return info;
    } catch (err) {
        throw err;
    }
}

export let checkIDCardAndBooking = async (chargingSpotID, cardID) => {
    const stmt = await sql.prepare(`SELECT Hour FROM User LEFT OUTER JOIN Booking ON User.Username = Booking.User
         WHERE Date = ? AND ChargingSpotID = ? AND CardID = ? ORDER BY CardID`);
    const stmt2 = await sql.prepare(`SELECT Username FROM User WHERE CardID = ?`);
    try {
        const currentDate = new Date();
        const today = currentDate.toISOString().split('T')[0];

        const data = await stmt.all(today, chargingSpotID, cardID);
        const idCardUser = await stmt2.all(cardID);

        const tuple = idCardUser[0];
        const username = tuple.Username;

        const currentHour = currentDate.getHours();

        let isThereABookingNow = 0;

        data.forEach(entry => {
            if(currentHour == entry.Hour) {
                isThereABookingNow = 1;
            }
        });
        return [isThereABookingNow, username]
    } catch (err) {
        throw err;
    }
}