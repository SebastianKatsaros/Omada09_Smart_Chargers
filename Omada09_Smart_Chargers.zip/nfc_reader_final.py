import os
import time
import json
import requests
from threading import Thread
from tkinter import Tk
import paho.mqtt.client as mqtt
from smartcard.System import readers
from smartcard.util import toHexString
from smart_charger_simulator_final import SmartChargerApp

INFLUXDB_HOST = os.getenv("INFLUXDB_HOST", '150.140.186.118')
INFLUXDB_PORT = os.getenv("INFLUXDB_PORT", "8086")
INFLUXDB_TOKEN = os.getenv("INFLUXDB_TOKEN", "6zf9dBYjDfrUlAOJ_A8-7sOLmg2oHvYEhH1SS03sWTEoveUDCJjBHpzTRC_sN8kDW-OVxsVl1QJsRACMMfG2eQ==")
INFLUXDB_ORG = os.getenv("INFLUXDB_ORG", "048abd758ddce8ae")
INFLUXDB_BUCKET = os.getenv("INFLUXDB_BUCKET", "BP$K")
INFLUXDB_WRITE_URL = f"http://{INFLUXDB_HOST}:{INFLUXDB_PORT}/api/v2/write"


def store_card_data_in_influxdb(card_uid, user_name, card_id, tele):
    line_data = f"nfc_tags,reader=smart_card_reader uid=\"{card_uid}\",username=\"{user_name}\",id=\"{card_id}\",telephone=\"{tele}\""
    headers = {"Authorization": f"Token {INFLUXDB_TOKEN}", "Content-Type": "text/plain; charset=utf-8"}
    params = {"org": INFLUXDB_ORG, "bucket": INFLUXDB_BUCKET, "precision": "s"}
    try:
        response = requests.post(INFLUXDB_WRITE_URL, params=params, data=line_data, headers=headers, timeout=5)
    except Exception as e:
        print(f"Error writing to InfluxDB: {e}")


class NFCReader:
    def __init__(self, app):
        self.app = app
        self.card_present = False
        self.card_read = False
        self.locked_card_uid = None  # Stores the currently authenticated card
        self.charging_active = False  # Prevents new cards during charging

        self.broker = "150.140.186.118"
        self.port = 1883
        self.topic = "omada_09/communication"
        self.mqtt_client = mqtt.Client()
        self.mqtt_client.connect(self.broker, self.port)

        self.mqtt_client.loop_start()
        self.mqtt_client.subscribe(self.topic)
        self.mqtt_client.on_message = lambda client, userdata, msg : print(f"Received `{msg.payload.decode()}`\
                                                                            from `{msg.topic}` topic")
        
        

    def reset_card_detection(self):
        self.card_present = False
        self.card_read = False
        self.locked_card_uid = None
        self.charging_active = False
        print("Card detection reset. Ready for a new session.")        
    def authenticate_card(self, connection, block):
        AUTH_CMD = [0xFF, 0x86, 0x00, 0x00, 0x05, 0x01, 0x00, block, 0x60, 0x00]
        response, sw1, sw2 = connection.transmit(AUTH_CMD)

        if sw1 == 0x90 and sw2 == 0x00:
            return True
        else:
            print(f"Authentication failed for block {block}: SW1={sw1}, SW2={sw2}")
            return False

    def read_full_card_data(self, connection):
        card_data = []
        for block in range(0, 16):
            if not self.authenticate_card(connection, block):
                break  # Stop reading if authentication fails

            READ_BLOCK = [0xFF, 0xB0, 0x00, block, 0x10]  # Read 16 bytes
            try:
                block_data, sw1, sw2 = connection.transmit(READ_BLOCK)
                if sw1 == 0x90 and sw2 == 0x00:
                    card_data.append(toHexString(block_data))
                else:
                    print(f"Error reading block {block}: SW1={sw1}, SW2={sw2}")
                    break
            except Exception as e:
                print(f"Error during block read {block}: {e}")
                break
        return " ".join(card_data)

    def run(self):
        def extract_username_data(card_data):
            start_marker = "55 73 65 72 6E 61 6D 65" 
            end_marker = "12 02 04" 

            # Ensure card_data is a string (convert list to string if needed)
            if isinstance(card_data, list):
                 card_data = " ".join(card_data)

            # Find marker positions
            start_idx = card_data.find(start_marker)
            end_idx = card_data.find(end_marker, start_idx)

            if start_idx == -1 and end_idx == -1:
               return None
            if end_idx <= start_idx:
               return None

            # Extract and return the substring between the markers
            extracted_user_data = card_data[start_idx + len(start_marker):end_idx].strip()
            ascii_text = bytes.fromhex(extracted_user_data.replace(" ", "")).decode("utf-8")
            return ascii_text

        def extract_id_data(card_data):
            start_marker = "49 44"
            end_marker = "52"

            if isinstance(card_data, list):
                 card_data = " ".join(card_data)

            start_idx = card_data.find(start_marker)
            end_idx = card_data.find(end_marker, start_idx)

            if start_idx == -1 and end_idx == -1:
               return None
            if end_idx <= start_idx:
               return None
            extracted_id_data = card_data[start_idx + len(start_marker):end_idx].strip()
            ascii_text = bytes.fromhex(extracted_id_data.replace(" ", "")).decode("utf-8")
            return ascii_text
        
        def extract_tel_data(card_data):
            start_marker = "09 0A 54 65 6C 65 70 68 6F 6E 65" 
            middle_marker = "00 00 00 00 00 00 FF 07 80 69 FF FF FF FF FF FF" 
            end_marker = "FE"
            if isinstance(card_data, list):
                 card_data = " ".join(card_data)

            start_idx = card_data.find(start_marker)
            middle_idx = card_data.find(middle_marker, start_idx)
            end_idx = card_data.find(end_marker, middle_idx)

            if start_idx == -1 and end_idx == -1 and middle_idx == -1:
               return None
            if not (start_idx < middle_idx < end_idx):
               return None
            extracted_tel1_data = card_data[start_idx + len(start_marker):middle_idx].strip()
            extracted_tel2_data = card_data[middle_idx + len(middle_marker):end_idx].strip()
            ascii_text_1 = bytes.fromhex(extracted_tel1_data.replace(" ", "")).decode("utf-8")
            ascii_text_2 = bytes.fromhex(extracted_tel2_data.replace(" ", "")).decode("utf-8")
            return ascii_text_1+ascii_text_2
        
        available_readers = readers()
        if len(available_readers) == 0:
            print("No smart card readers found.")
            return

        reader = available_readers[0]
        print("Using reader:", reader)
        
        def on_message(client, userdata, msg):
            data = json.loads(msg.payload.decode())
            if not self.app.authenticated:
                if data['request']=="authentication-message":
                    if data['chargingSpot']==self.app.chargingSpotID:
                        if data['authenticate']:
                            self.app.authenticate(data['username'])
                            self.app.display_message(f"Hello, you are authenticated")
                            self.charging_active = True  # Lock session
                        else: 
                            self.app.display_message("Outside of Booked Hours")
                            time.sleep(2.5)
                            self.reset_card_detection()
                            self.app.display_message("You can authenticate now")
        
        self.mqtt_client.on_message = on_message 

        connection = reader.createConnection()

        while True:
            try:
                connection.connect()

                if self.card_present or self.charging_active:
                    time.sleep(0.5)  # Reduce CPU usage while waiting
                    continue

                print("Card detected and connected!")
                self.card_present = True
                GET_UID = [0xFF, 0xCA, 0x00, 0x00, 0x00]
                uid_response, sw1, sw2 = connection.transmit(GET_UID)
                card_data = self.read_full_card_data(connection)
                username = extract_username_data(card_data)
                id = extract_id_data(card_data)
                tel = extract_tel_data(card_data)
                if username != None and id != None and tel != None:  
                    if sw1 == 0x90 and sw2 == 0x00:
                        card_uid = toHexString(uid_response)
                        if self.locked_card_uid is not None and card_uid != self.locked_card_uid:
                                continue  # Ignore any other card detected
                        if self.locked_card_uid is None: 
                                self.locked_card_uid = card_uid
                                self.app.display_message(f"Hello, you are authenticated")
                        self.card_read = True                                       
                        if not self.app.authenticated:
                                message = {"request": "authentication-request", "cardID": int(id), "stationID": self.app.chargingSpotID}
                                self.mqtt_client.publish(self.topic, json.dumps(message))
                                
                    store_card_data_in_influxdb(card_uid, username, id, tel)
                else:
                    self.app.display_message(f"Invalid NFC Card")
                    Thread(target=self.app.clear_invalid_message, daemon=True).start()
                self.card_read = True
                while self.card_present:
                        time.sleep(0.5)
                        try:
                            connection.connect()  # If this fails, the card was removed
                        except:
                            print("Card removed.")
                            self.card_present = False
                            self.card_read = False
                            break
            except Exception as e:
                if self.card_present:
                    print("Card removed.")
                    self.card_present = False
                    self.card_read = False
                    self.mqtt_client.on_message = lambda client, userdata, msg : print(f"Received `{msg.payload.decode()}`\
                                                                                from `{msg.topic}` topic")
            time.sleep(2.5)


if __name__ == "__main__":
    root = Tk()
    app = SmartChargerApp(root)
    def finish_charging():
        print("Charging session completed. Resetting for next card.")
        app.nfc_reader.reset_card_detection()
    app.finish_charging_callback = finish_charging  # Ensure GUI can trigger reset
    nfc_reader = NFCReader(app)
    app.nfc_reader = nfc_reader
    nfc_thread = Thread(target=nfc_reader.run, daemon=True)
    nfc_thread.start()
    root.mainloop()
    nfc_reader.mqtt_client.loop_start()