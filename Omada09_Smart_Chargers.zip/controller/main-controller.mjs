
import * as model from '../model/sqlite-async/model.mjs';

export let getChargingPoints = async (req, res) => {
    try {
        const chargePoints = await model.getAllChargingPoints();
        res.json(chargePoints);
    } catch (error) {
        console.error('Error mapping out charge points:', error);
        res.status(500).json({ error: 'Internal Server Error' });
    }
}

export let getCurrentUser = async (req, res) => {
    try {
        const currentUser = req.session.user;
        var isThereAUser = 1;
        if (currentUser == undefined) {
            isThereAUser = 0;
            res.json({user: isThereAUser});
        }
        else {
            res.json({user: isThereAUser, first_name: currentUser.firstName, 
                last_name: currentUser.lastName, username: currentUser.username
            });
        }
    } catch (error) {
        console.error('Error finding current user:', error);
        res.status(500).json({ error: 'Internal Server Error' });
    }
}

export let checkAvailability = async (req, res) => {
   const date = req.query.date;
   const stationID = req.query.stationID;
   if (!date) {
       return res.status(400).json({ error: 'Date is required' });
   }

   try {
       const bookings = await model.getChargingSpotAvailability(date, stationID);
       res.json({ bookings });
   } catch (error) {
       console.error('Error checking availability:', error);
       res.status(500).json({ error: 'Internal Server Error' });
   }
};

export let bookChargingSpot = async (req, res) => {
   const {  date, stationID, hour } = req.body;
   const memberUsername = req.session.user.username;
   console.log(`Booking request received: Date: ${date}, Station ID: ${stationID}, Hour: ${hour}, Member Username: ${memberUsername}`);


   try {
       await model.saveChargingSpotBooking(date, memberUsername, stationID, hour); 
       res.status(200).json({ message: 'Booking successful' });

   } catch (error) {
       console.error('Error renting court:', error);
       res.status(500).send('Internal Server Error');
   }
};

export const showBookings = async (req, res) => {
    const user = req.session.user ? req.session.user : null;
    if (!user) {
        console.error('No user found in session');  
        return res.status(401).send('User not authenticated');
    }
    const first_name = user.firstName;
    const last_name = user.lastName;
    try {
        let bookings = await model.getBookingsForMember(user.username);
        bookings.forEach(booking => {
            booking.Date = new Date(booking.Date);
            booking.Date = booking.Date.toDateString();
        });

        res.render('my-bookings', { bookings, first_name, last_name });
    } catch (error) {
        console.error('Error in showBookings:', error);  
        res.status(500).send('Error retrieving bookings');
    }
};

export const showChargingStatus = async (req, res) => {
    const user = req.session.user ? req.session.user : null;
    if (!user) {
        console.error('No user found in session');  
        return res.status(401).send('User not authenticated');
    }
    try {
        let vehicle = await model.getMemberVehicle(user.username);
        vehicle = vehicle[0];

        res.render('charging-status', { vehicle });
    } catch (error) {
        console.error('Error in showChargingStatus:', error);  
        res.status(500).send('Error retrieving Charging Status details');
    }
};

export let getUserBookings = async (req, res) => {
    const date = req.query.date;
    const user = req.session.user ? req.session.user : null;
 
     if (!user) {
         console.error('No user found in session');  
         return res.status(401).send('User not authenticated');
     }
     const username = user.username;
     try {
         const userBookingHours = await model.getUserBookingHours(username, date);
         res.json(userBookingHours);
     } catch (error) {
         console.error('Error mapping out charge points:', error);
         res.status(500).json({ error: 'Internal Server Error' });
     }
 }

 
export let getChargingSpotInfo = async (req, res) => {
    const chargingSpotID = req.query.stationID;
     try {
         const info = await model.getChargingSpotInformation(chargingSpotID);
         res.json(info);
     } catch (error) {
         console.error('Error mapping out charge points:', error);
         res.status(500).json({ error: 'Internal Server Error' });
     }
 }

 export let authenticateUserIDCard = async (req, res) => {
    const chargingSpotID = req.query.stationID;
    const cardID = req.query.cardID;
     try {
         const info = await model.checkIDCardAndBooking(chargingSpotID, cardID);
         res.json(info);
     } catch (error) {
         console.error('Error mapping out charge points:', error);
         res.status(500).json({ error: 'Internal Server Error' });
     }
 }