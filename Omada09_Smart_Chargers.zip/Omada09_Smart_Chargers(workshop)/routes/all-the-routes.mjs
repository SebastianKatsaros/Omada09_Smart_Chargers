import express from 'express';
const router = express.Router();

import * as mainController from '../controller/main-controller.mjs';
import * as loginController from '../controller/login-controller.mjs';

router.route('/').get((req, res) => {
    res.render('map-tab');
});

router.route('/get-charging-points').get(mainController.getChargingPoints);

router.route('/get-current-user').get(mainController.getCurrentUser);


router.route('/register')
    .get(loginController.redirectAuthenticated, loginController.showRegisterForm)
    .post(loginController.completeRegistration);

router.route('/login')
    .get(loginController.redirectAuthenticated, loginController.showLogInForm)
    .post(loginController.loginUser);

router.route('/logout').get(loginController.doLogout);


router.route('/booking')
    .get(loginController.checkAuthenticated, (req, res) => {
        res.render('booking');
    })
    .post(loginController.checkAuthenticated, mainController.bookChargingSpot);

router.route('/my-bookings')
    .get(loginController.checkAuthenticated, mainController.showBookings);

router.route('/check-availability')
    .get(loginController.checkAuthenticated, mainController.checkAvailability);

router.route('/book-charging-spot')
    .post(loginController.checkAuthenticated, mainController.bookChargingSpot);


router.route('/charging-status')
    .get(loginController.checkAuthenticated, mainController.showChargingStatus);

router.route('/get-user-bookings')
    .get(loginController.checkAuthenticated, mainController.getUserBookings);

router.route('/get-charging-spot-info').get(mainController.getChargingSpotInfo);

router.route('/authenticate-user-id-card').get(mainController.authenticateUserIDCard);

router.route('/cancel-booking')
    .post(loginController.checkAuthenticated, mainController.cancelBooking);

export default router;
