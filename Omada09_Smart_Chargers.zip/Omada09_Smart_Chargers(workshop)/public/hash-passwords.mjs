'use strict';
import { Database } from 'sqlite-async';
import bcrypt from 'bcrypt';

export async function hashExistingPasswords() {
    let sql;
    try {
        sql = await Database.open('./model/db/smart-charging.sqlite');
        const users = await sql.all("SELECT Username, Password FROM User");

        for (const user of users) {
            const isHashed = user.Password.startsWith('$2b$');
            if (!isHashed) {
                const hashedPassword = await bcrypt.hash(user.Password, 10);
                await sql.run("UPDATE User SET Password = ? WHERE Username = ?", [hashedPassword, user.Username]);
            }
        }

        console.log("All passwords have been hashed successfully.");
    } catch (error) {
        console.error("Error hashing passwords: ", error);
    } finally {
        if (sql) {
            await sql.close();
        }
    }
}

// hashExistingPasswords();
