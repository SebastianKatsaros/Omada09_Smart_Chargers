import express from 'express';
import dotenv from 'dotenv';
import exphbs from 'express-handlebars';
import mySession from './app-setup/app-setup-session.mjs';
import routes from './routes/all-the-routes.mjs';

const app = express();

if (process.env.NODE_ENV !== 'production') {
    dotenv.config();
}

app.use(express.urlencoded({ extended: false }));
app.use(express.json());

app.use(mySession);

app.use(express.static('public/'));

app.use((req, res, next) => {
    res.locals.user = req.session.user;
    next();
});

app.use('/', routes);

app.use((err, req, res, next) => {
    res.status(500);
    res.render('error', { message: err.message, stacktrace: err.stack });
});

const hbs = exphbs.create({
    extname: 'hbs',
    helpers: {
        eq: (a, b) => a === b,
        ifNot: (condition, options) => {
            if (!condition) {
                return options.fn(this);
            } else {
                return options.inverse(this);
            }
        }
    }
});

app.engine(
    'hbs',
    exphbs.engine({
        extname: 'hbs',
    })
);
app.set('view engine', 'hbs');

export { app as chargingSpotsApp };
