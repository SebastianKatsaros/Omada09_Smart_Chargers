import paho.mqtt.client as mqtt
import json
import time
from datetime import datetime
from random import randint

BROKER = '150.140.186.118'
PORT = 1883
PUBLISH_TOPIC = "omada_09/status_update"

def publish_parking_status():
    client = mqtt.Client()
    client.connect(BROKER, PORT)
    
    time.sleep(randint(3,7))
    message = {
        "carStatus": 1.0,
        "time": datetime.utcnow().strftime('%Y-%m-%dT%H:%M:%S'),
        "statusMessage": "OCCUPIED"
    }

    json_message = json.dumps(message)
    client.publish(PUBLISH_TOPIC, json_message)
    print(f"Published: {json_message}")
    client.disconnect()

def publish_parking_available():
    client = mqtt.Client()
    client.connect(BROKER, PORT)
    time.sleep(randint(2,8))
    message = {
        "carStatus": 0.0,
        "time": datetime.utcnow().strftime('%Y-%m-%dT%H:%M:%S'),
        "statusMessage": "AVAILABLE"
    }
    
    json_message = json.dumps(message)
    client.publish(PUBLISH_TOPIC, json_message)
    print(f"Published: {json_message}")
    client.disconnect()

if __name__ == "__main__":
    print("Parking message handler ready to publish status updates.")
