import tkinter as tk
from tkinter import ttk
import random
from PIL import Image, ImageTk
import time
import os
import subprocess
import requests
from threading import Thread
import paho.mqtt.client as mqtt
from parking_msg_handler import *
import sqlite3
import json

INFLUXDB_HOST = os.getenv("INFLUXDB_HOST", '150.140.186.118')
INFLUXDB_PORT = os.getenv("INFLUXDB_PORT", "8086")
INFLUXDB_TOKEN = os.getenv("INFLUXDB_TOKEN", "6zf9dBYjDfrUlAOJ_A8-7sOLmg2oHvYEhH1SS03sWTEoveUDCJjBHpzTRC_sN8kDW-OVxsVl1QJsRACMMfG2eQ==")
INFLUXDB_ORG = os.getenv("INFLUXDB_ORG", "048abd758ddce8ae")
INFLUXDB_BUCKET = os.getenv("INFLUXDB_BUCKET", "BP$K")
INFLUXDB_WRITE_URL = f"http://{INFLUXDB_HOST}:{INFLUXDB_PORT}/api/v2/write"

def store_charge_data_in_influxdb(battery_level):
    line_data = f"charging,reader=battery percentage=\"{battery_level}\""
    headers = {"Authorization": f"Token {INFLUXDB_TOKEN}", "Content-Type": "text/plain; charset=utf-8"}
    params = {"org": INFLUXDB_ORG, "bucket": INFLUXDB_BUCKET, "precision": "s"}
    try:
        requests.post(INFLUXDB_WRITE_URL, params=params, data=line_data, headers=headers, timeout=5)
    except Exception as e:
        print(f"Error writing to InfluxDB: {e}")

class SmartChargerApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Smart Charger Simulator")
        self.root.geometry("500x500")
        self.root.resizable(False, False)
        
        # Configure style
        self.style = ttk.Style()
        self.style.configure('Modern.TButton',
                           font=('Helvetica', 12, 'bold'),
                           padding=10,
                           relief='flat')

        self.canvas = tk.Canvas(self.root, width=500, height=500, highlightthickness=0, bg='#2C3E50')
        self.canvas.pack(fill="both", expand=True)
        
        # Create gradient background
        for i in range(500):
            color = self.interpolate_color('#2C3E50', '#34495E', i/500)
            self.canvas.create_line(0, i, 500, i, fill=color)

        __location__ = os.path.realpath(
            os.path.join(os.getcwd(), os.path.dirname(__file__)))
        self.bg_image = Image.open(os.path.join(__location__, 'public', 'img', 'image01.png')).resize((500, 500), Image.LANCZOS)
        self.bg_photo = ImageTk.PhotoImage(self.bg_image)
        self.canvas.create_image(0, 0, image=self.bg_photo, anchor="nw")

        self.charging = False
        self.battery_level = random.randint(0, 90)
        self.authenticated = False
        self.first_charge = False
        self.bar_up = False
        self.charge_session_id = 0
        self.currentUser = ""

        self.charger_text = self.canvas.create_text(
            180, 450,
            text="Select Charging Spot ID:",
            font=("Helvetica", 12, "bold"),
            fill="#FFFFFF"
        )
        spot_ids = self.get_station_ids_from_db()
        self.charger_choice = tk.StringVar(value=spot_ids[0])
        self.charger_option = tk.OptionMenu(self.canvas, self.charger_choice, *spot_ids)
        self.charger_choice.trace_add("write", lambda *args: self.update_charging_spot())
        self.charger_option.config(
            font=("Helvetica", 12, "bold"),
            bg="#34495E",
            fg="white",
            activebackground="#2C3E50",
            activeforeground="white",
            highlightthickness=0,
            relief="flat",
            borderwidth=0
        )
        self.charger_option["menu"].config(
            bg="#34495E",
            fg="white",
            activebackground="#2C3E50",
            activeforeground="white",
            relief="flat",
            borderwidth=0
        )
        self.charger_option_window = self.canvas.create_window(375, 450, window=self.charger_option)
        self.chargingSpotID = int(self.charger_choice.get())

        self.broker = "150.140.186.118"
        self.port = 1883
        self.publish_topic = "omada_09/charging_process"
        self.parking_sensor_topic = "omada_09/status"
        self.communication_topic = "omada_09/communication"
        
        # MQTT clients
        self.mqtt_client = mqtt.Client()
        self.mqtt_client_parking = mqtt.Client()
        self.mqtt_client_communication = mqtt.Client()
        
        self.mqtt_client.connect(self.broker, self.port)
        self.mqtt_client_parking.connect(self.broker, self.port)
        self.mqtt_client_communication.connect(self.broker, self.port)
        
        self.mqtt_client.loop_start()
        self.mqtt_client_parking.loop_start()
        self.mqtt_client_communication.loop_start()

        # Subscribe to topics
        self.mqtt_client.subscribe(self.publish_topic)
        self.mqtt_client_parking.subscribe(self.parking_sensor_topic)
        self.mqtt_client_communication.subscribe(self.communication_topic)

        def on_charging_message(client, userdata, msg):
            data = json.loads(msg.payload.decode())
            if data['request']=="are-you-charging":
                if data['user']==self.currentUser:
                    if self.charging:
                        message = {
                            "request": "charging-message", 
                            "username": self.currentUser,
                            "stationID": self.chargingSpotID, 
                            "stop": 0,
                            "battery_level": self.battery_level
                        }
                        self.mqtt_client_communication.publish(self.communication_topic, json.dumps(message))

        self.mqtt_client_communication.on_message = on_charging_message

        self.battery_shapes = []

        self.battery_text = self.canvas.create_text(
            245, 150,
            text=f"Battery: {self.battery_level}%",
            font=("Helvetica", 16, "bold"),
            fill="#00E676",
            state='hidden'
        )
        
        self.state_text = self.canvas.create_text(
            245, 55,
            text="State: Disconnected",
            font=("Helvetica", 14, "bold"),
            fill="#B3E5FC"
        )
        
        self.bar_text = self.canvas.create_text(
            245, 85,
            text="Bar: Down",
            font=("Helvetica", 14, "bold"),
            fill="#FF8A80"
        )

        self.toggle_button = tk.Button(
            self.canvas,
            text="Start Charging",
            command=self.toggle_charging,
            font=("Helvetica", 12, "bold"),
            bg="#4CAF50",
            fg="white",
            relief="flat",
            padx=25,
            pady=10,
            state="disabled",
            cursor="hand2",
            activebackground="#45a049",
            activeforeground="white",
            borderwidth=0,
            highlightthickness=0
        )
        self.toggle_button_id = self.canvas.create_window(245, 310, window=self.toggle_button)

        self.finish_button = tk.Button(
            self.canvas,
            text="Finish Charging",
            command=self.finish_charging,
            font=("Helvetica", 12, "bold"),
            bg="#FF5252",
            fg="white",
            relief="flat",
            padx=25,
            pady=10,
            state="disabled",
            cursor="hand2",
            activebackground="#FF1744",
            activeforeground="white",
            borderwidth=0,
            highlightthickness=0
        )
        self.finish_button_id = self.canvas.create_window(245, 360, window=self.finish_button, state='hidden')

        def on_enter(e):
            e.widget['background'] = '#45a049' if e.widget == self.toggle_button else '#FF1744'
            e.widget['relief'] = 'flat'
            e.widget['borderwidth'] = 0

        def on_leave(e):
            e.widget['background'] = '#4CAF50' if e.widget == self.toggle_button else '#FF5252'
            e.widget['relief'] = 'flat'
            e.widget['borderwidth'] = 0

        self.toggle_button.bind("<Enter>", on_enter)
        self.toggle_button.bind("<Leave>", on_leave)
        self.finish_button.bind("<Enter>", on_enter)
        self.finish_button.bind("<Leave>", on_leave)

        def update_button_appearance(button, is_enabled):
            if is_enabled:
                button.config(
                    state="normal",
                    bg="#4CAF50" if button == self.toggle_button else "#FF5252",
                    cursor="hand2"
                )
            else:
                button.config(
                    state="disabled",
                    bg="#9E9E9E",
                    cursor="arrow"
                )

        self.update_button_appearance = update_button_appearance

        self.message_text = self.canvas.create_text(
            245, 412,
            text="",
            font=("Helvetica", 14, "bold"),
            fill="#FFD54F"
        )
        self.display_message("You can authenticate now")

    @staticmethod
    def get_station_ids_from_db():
        try:
            __location__ = os.path.realpath(
                os.path.join(os.getcwd(), os.path.dirname(__file__)))
            db_path = os.path.join(__location__, 'model', 'db', 'smart-charging.sqlite')
            conn = sqlite3.connect(db_path)
            cursor = conn.cursor()
            cursor.execute("SELECT StationID FROM Charging_Point")
            spot_ids = [str(row[0]) for row in cursor.fetchall()]
            conn.close()
            if not spot_ids:
                print("Warning: No charging stations found in database")
                return ["1"]  # fallback to ["1"] if empty
            return spot_ids
        except sqlite3.Error as e:
            print(f"Database error: {e}")
            return ["1"]  # fallback in case of DB error
        except Exception as e:
            print(f"Unexpected error fetching station IDs: {e}")
            return ["1"]  # fallback other error

    def update_charging_spot(self):
        try:
            self.chargingSpotID = int(self.charger_choice.get())
        except ValueError:
            self.chargingSpotID = 1  # fallback default

    def display_message(self, message):
        self.canvas.itemconfig(self.message_text, text=message)

    def show_battery_text(self):
        self.canvas.itemconfigure(self.battery_text, state='normal')

    def hide_battery_text(self):
        self.canvas.itemconfigure(self.battery_text, state='hidden')

    def set_battery_text(self, new_text):
        self.canvas.itemconfig(self.battery_text, text=new_text)

    def set_state_text(self, new_text, fill="#B3E5FC"):
        self.canvas.itemconfig(self.state_text, text=new_text, fill=fill)

    def set_bar_text(self, new_text, fill="#FF8A80"):
        self.canvas.itemconfig(self.bar_text, text=new_text, fill=fill)

    def hide_finish_button(self):
        self.canvas.itemconfigure(self.finish_button_id, state='hidden')

    def show_finish_button(self):
        self.canvas.itemconfigure(self.finish_button_id, state='normal')

    def get_state_text(self):
        return self.canvas.itemcget(self.state_text, "text")

    def hide_charging_spot_selection(self):
        self.canvas.itemconfigure(self.charger_text, state='hidden')
        self.canvas.itemconfigure(self.charger_option_window, state='hidden')

    def show_charging_spot_selection(self):
        self.canvas.itemconfigure(self.charger_text, state='normal')
        self.canvas.itemconfigure(self.charger_option_window, state='normal')

    def authenticate(self, username):
        self.display_message("") # Clear message before attempting authentication
        if not self.bar_up and self.get_state_text() == "State: Disconnected":
            self.currentUser = username
            if not self.authenticated:
                self.authenticated = True
                self.set_state_text("State: Authenticated", fill="#B3E5FC")
                self.set_bar_text("Bar: Going Up", fill="#FFB74D")
                self.bar_up = True
                self.toggle_button.config(state="disabled")
                self.battery_level = random.randint(0, 90)
                self.set_battery_text(f"Battery: {self.battery_level}%")
                self.hide_charging_spot_selection()
                Thread(target=self.bar_up_and_enable_start, daemon=True).start()
                self.publish_message(f"Authentication successful.")
        else:
            self.display_message("Cannot authenticate - wait for bar to go down")
            Thread(target=self.clear_invalid_message, daemon=True).start()
            self.publish_message("Authentication failed - wait for bar to go down")

    def bar_up_and_enable_start(self):
        time.sleep(3)
        self.set_bar_text("Bar: Up", fill="#69F0AE")
        self.bar_up = True
        def on_message(client, userdata, msg):
           data = json.loads(msg.payload.decode())
           if data['carStatus']:
               publish_parking_status()
               time.sleep(2)
               self.toggle_button.config(state="normal")
        self.mqtt_client_parking.on_message = on_message 
        print("Awaiting car.")
        __location__ = os.path.realpath(
        os.path.join(os.getcwd(), os.path.dirname(__file__)))
        subprocess.run(['python', os.path.join(__location__, 'mqtt_publisher_1.py')])

    def finish_charging_callback(self):
        return None
    
    def toggle_charging(self):
        if not self.charging:
            # Start charging
            self.charging = True
            message = {
                "request": "charging-message", 
                "username": self.currentUser,
                "stationID": self.chargingSpotID, 
                "stop": 0,
                "battery_level": self.battery_level
            }
            self.mqtt_client_communication.publish(self.communication_topic, json.dumps(message))

            if self.get_state_text() == "State: Disconnected":
                self.authenticate()
                return

            if not self.first_charge:
                self.first_charge = True
                self.set_bar_text("Bar: Going Down", fill="#FFAC1C")
                self.toggle_button.config(state="disabled", bg="#808080")
                self.display_message("")
                Thread(target=self.bar_going_down_sequence, daemon=True).start()

            self.show_battery_text()
            self.draw_battery_bar()

            self.toggle_button.config(text="Stop Charging", bg="#73AFC8")
            self.show_finish_button()
            self.finish_button.config(state="disabled")

            self.set_state_text("State: Charging", fill="#B3E5FC")
            self.publish_message("Charging started")

            self.start_charging()
        else:
            self.charging = False
            message = {
                "request": "charging-message", 
                "username": self.currentUser,
                "stationID": self.chargingSpotID, 
                "stop": 1,
                "battery_level": self.battery_level
            }
            self.mqtt_client_communication.publish(self.communication_topic, json.dumps(message))
            
            self.toggle_button.config(text="Continue Charging", bg="#28B463")
            self.set_state_text("State: Paused", fill="#B3E5FC")
            self.finish_button.config(state="normal")

            self.publish_message("Charging stopped")

    def bar_going_down_sequence(self):
        time.sleep(3)
        self.set_bar_text("Bar: Down", fill="red")
        self.toggle_button.config(state="normal")

    def finish_charging(self):
        if self.charging:
            return  # do nothing if still charging

        # Stop charging & reset
        self.charging = False
        self.clear_battery_shapes()
        self.hide_battery_text()
        self.first_charge = False
        self.display_message("")
        self.authenticated = False

        self.hide_finish_button()
        self.toggle_button.config(state="disabled", text="Start Charging", bg="#E0AC00")
        self.finish_button.config(state="disabled")
        self.set_state_text("State: Finished", fill="#B3E5FC")
        self.set_bar_text("Bar: Going Up", fill="#FFB74D")

        Thread(target=self.bar_up_after_finish, daemon=True).start()
        self.publish_message("Charging finished.")

    def bar_up_after_finish(self):
        self.display_message("") # Clear message immediately after finishing charge
        message = {"request": "charging-message", "username": self.currentUser,
                                    "stationID": self.chargingSpotID, "stop": 1}
        self.mqtt_client_communication.publish(self.communication_topic, json.dumps(message))
        time.sleep(3)
        self.set_bar_text("Bar: Up", fill="#69F0AE")
        self.bar_up = True
        def on_message(client, userdata, msg):
           statusData = json.loads(msg.payload.decode())
           if not statusData['carStatus']:
               publish_parking_available()
               Thread(target=self.bar_goes_down, daemon=True).start()
        self.mqtt_client_parking.on_message = on_message

        print("Awaiting car to leave.")
        __location__ = os.path.realpath(
        os.path.join(os.getcwd(), os.path.dirname(__file__)))
        subprocess.run(['python', os.path.join(__location__, 'mqtt_publisher_0.py')])

    def bar_goes_down(self):
        self.display_message("") # Clear message as bar starts going down
        time.sleep(4)
        self.set_bar_text("Bar: Going Down", fill="#FFAC1C")
        Thread(target=self.bar_down_before_next_auth, daemon=True).start()

    def bar_down_before_next_auth(self):
        time.sleep(3)
        self.set_bar_text("Bar: Down", fill="#FF8A80")
        self.set_state_text("State: Disconnected", fill="#B3E5FC")
        self.authenticated = False
        self.charging = False
        self.bar_up = False
        self.finish_charging_callback()
        self.show_charging_spot_selection()
        self.display_message("You can authenticate now")
        
    def start_charging(self):
        def charge():
            while self.charging and self.battery_level < 100:
                store_charge_data_in_influxdb(self.battery_level)
                time.sleep(5)
                if not self.charging:
                    break
                self.battery_level += 1
                self.update_ui()
                
                if self.battery_level >= 100:
                    self.battery_level = 100
                    self.charging = False
                    self.clear_battery_shapes()
                    self.hide_battery_text()
                    self.first_charge = False
                    self.display_message("")
                    self.set_state_text("State: Finished", fill="#B3E5FC")
                    self.set_bar_text("Bar: Going Up", fill="#FFB74D")
                    Thread(target=self.bar_up_after_full, daemon=True).start()
                    self.publish_message("Battery fully charged.")
                    break
        Thread(target=charge, daemon=True).start()

    def bar_up_after_full(self):
        message = {"request": "charging-message", "username": self.currentUser,
                                    "stationID": self.chargingSpotID, "stop": 1}
        self.mqtt_client_communication.publish(self.communication_topic, json.dumps(message))
        time.sleep(3)
        self.set_bar_text("Bar: Up", fill="#69F0AE")
        self.bar_up = True
        def on_message(client, userdata, msg):
           statusData = json.loads(msg.payload.decode())
           if not statusData['carStatus']:
               publish_parking_available()
               Thread(target=self.bar_goes_down, daemon=True).start()
        self.mqtt_client_parking.on_message = on_message

        print("Awaiting car to leave.")
        __location__ = os.path.realpath(
        os.path.join(os.getcwd(), os.path.dirname(__file__)))
        subprocess.run(['python', os.path.join(__location__, 'mqtt_publisher_0.py')])

    def update_ui(self):
        self.draw_battery_bar()
        self.set_battery_text(f"Battery: {self.battery_level}%")

        if self.battery_level >= 100:
            self.toggle_button.config(state="disabled", text="Start Charging", bg="#E0AC00")
            self.hide_finish_button()

        # Ensure no authentication message appears during the transition after finishing charging
        if self.get_state_text() == "State: Finished" and not self.bar_up:
             self.display_message("")

    def draw_battery_bar(self):
        self.clear_battery_shapes()

        battery_width = 250
        battery_height = 60
        cap_width = 20
        cap_height = 20

        x1 = 115
        y1 = 170
        x2 = x1 + battery_width
        y2 = y1 + battery_height

        outline_id = self.canvas.create_rectangle(x1, y1, x2, y2, outline="white", width=5)
        self.battery_shapes.append(outline_id)

        cap_id = self.canvas.create_rectangle(
            x2, y1 + (battery_height - cap_height)//2,
            x2 + cap_width, y1 + (battery_height + cap_height)//2,
            outline="white",
            width=3
        )
        self.battery_shapes.append(cap_id)

        fill_x2 = x1 + (self.battery_level / 100) * (battery_width - 10)
        fill_id = self.canvas.create_rectangle(x1 + 5, y1 + 5, fill_x2, y2 - 5, fill="#AAFF00")
        self.battery_shapes.append(fill_id)

    def clear_battery_shapes(self):
        for shape_id in self.battery_shapes:
            self.canvas.delete(shape_id)
        self.battery_shapes.clear()

    def publish_message(self, message):
        self.mqtt_client.publish(self.publish_topic, message)

    def clear_invalid_message(self):
        time.sleep(2)
        if not self.bar_up and self.get_state_text() == "State: Disconnected":
            self.display_message("You can authenticate now")
        else:
            self.display_message("")

    def interpolate_color(self, color1, color2, factor):
        def hex_to_rgb(hex_color):
            hex_color = hex_color.lstrip('#')
            return tuple(int(hex_color[i:i+2], 16) for i in (0, 2, 4))
        
        def rgb_to_hex(rgb):
            return '#{:02x}{:02x}{:02x}'.format(int(rgb[0]), int(rgb[1]), int(rgb[2]))
        
        rgb1 = hex_to_rgb(color1)
        rgb2 = hex_to_rgb(color2)
        interpolated = tuple(rgb1[i] + (rgb2[i] - rgb1[i]) * factor for i in range(3))
        return rgb_to_hex(interpolated)

if __name__ == "__main__":
    root = tk.Tk()
    app = SmartChargerApp(root)
    root.mainloop()