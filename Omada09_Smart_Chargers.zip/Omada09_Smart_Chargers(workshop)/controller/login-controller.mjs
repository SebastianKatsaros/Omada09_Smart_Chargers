import bcrypt from 'bcrypt';
import * as model from '../model/sqlite-async/model.mjs';

export let showLogInForm = function (req, res) {
    res.render('login', { model: process.env.MODEL, user: req.session.user });
}

export let showRegisterForm = function (req, res) {
    res.render('register', { user: req.session.user });
}

export let completeRegistration = async function (req, res) {
    try {
        const { username, password, first_name, last_name, phone, vehicle } = req.body;
        const registrationResult = await model.registerUser(username, password, first_name, last_name, phone, vehicle);
        if (registrationResult.message) {
            res.render('register', { message: registrationResult.message, user: req.session.user });
        } else {
            res.redirect('/login');
        }
    } catch (error) {
        console.error('registration error: ' + error);
        res.render('register', { message: error, user: req.session.user });
    }
}

export let loginUser = async function (req, res) {
    const user = await model.getUserByUsername(req.body.username);
    if (user == undefined || !user.Password) {
        res.render('login', { message: 'User not found', user: req.session.user });
    } else {
        const match = await bcrypt.compare(req.body.password, user.Password);
        if (match) {
            const members = await model.getAllMembers();
            const member = members.find(member => member.Username === user.Username);
            req.session.user = {
                username: user.Username,
                firstName: member.FirstName,
                lastName: member.LastName
            };
            //console.log('User authenticated:', req.session.user);  
            const redirectTo = req.session.originalUrl || "/";
            res.redirect(redirectTo);
        } else {
            res.render("login", { message: 'Wrong Password', user: req.session.user });
        }
    }
};

export let doLogout = (req, res) => {
    req.session.destroy((err) => {
        if (err) {
            console.error('Failed to destroy session during logout', err);
            return res.redirect('/');
        }

        res.clearCookie('connect.sid', { path: '/' });
        
        res.redirect('/');
    });
}

export let checkAuthenticated = function (req, res, next) {
    if (req.session.user) {
        //console.log("user is authenticated", req.originalUrl);
        next();
    } else {
        if ((req.originalUrl === "/login") || (req.originalUrl === "/register")) {
            next();
        } else {
            console.log("not authenticated, redirecting to /login");
            res.redirect('/login');
        }
    }
}

export let redirectAuthenticated = function (req, res, next) {
    if (req.session.user) {
        res.redirect('/');
    } else {
        next();
    }
}
