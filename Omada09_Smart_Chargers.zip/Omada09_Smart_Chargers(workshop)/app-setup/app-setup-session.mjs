import session from 'express-session';
import dotenv from 'dotenv';

if (process.env.NODE_ENV !== 'production') {
   dotenv.config();
}

const sessionConf = {
   secret: process.env.SESSION_SECRET,
   cookie: { maxAge: 1000*60*60*24, sameSite: true },
   resave: false,
   saveUninitialized: false,
};

let mySession = session(sessionConf);

export default mySession;
