import paho.mqtt.client as mqtt_client
import random
import json
import time

broker = '150.140.186.118'
port = 1883
client_id = 'rand_id' +str(random.random())
topic = "omada_09/status"
message = {"carStatus": 1}


def run():
    def on_connect(client, userdata, flags, rc):
        if rc == 0:
            print("Connected to MQTT Broker!")
        else:
            print(f"Failed to connect, return code {rc}\n")

    client = mqtt_client.Client(client_id)
    client.on_connect = on_connect
    client.connect(broker, port)
    time.sleep(1)
    client.publish(topic, json.dumps(message))
    client.disconnect()

if __name__ == '__main__':
    run()
